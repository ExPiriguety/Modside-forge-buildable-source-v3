# modside (Forge 1.20.1) — by noobits

Shows which of your mods are **client-only**, **server-only** or **needed on both sides**, which ones are
**libraries**, and what each mod depends on. Optional on both sides (the client can join a server without it and vice versa).
Mostra quais mods são somente de cliente, somente de servidor ou dos dois lados, quais são bibliotecas e suas dependências.

## Use / Uso
- **Client / Cliente:** press `]` (rebindable in Controls) or open **Mods > modside > Config**.
  Color legend: blue = client only, orange = server only, green = client + server.
  Button "Generate client report" writes `config/modside/report-client.html`.
- **Server / Servidor:** console `modside report` (or `/modside report` as operator) writes
  `config/modside/report-server.html` (+ `.json` and `removable-from-server-server.txt`). `modside summary` prints a short summary.
- Each side reads its own `mods/` folder; client and server reports never overwrite each other.

## Language / Idioma
`config/modside/modside.toml` (created on first run, client and server):

    language = "auto"   # "auto" | "en" | "pt_br"

- `auto`: client follows the game language (Portuguese or English); **server uses English**.
- `en` / `pt_br`: force a language. Anything that is not Portuguese falls back to English.
- Edit the file on the server and run the command again; no restart needed.
- The Forge Mods menu description is shown in English with a Portuguese (PT-BR) paragraph (Forge does not translate it).

## Known mods / Mods conhecidos
`config/modside/known_mods.json` is editable (client_only / server_only / libraries).

## Build
1. JDK 17 (JAVA_HOME).
2. Copy `gradlew`, `gradlew.bat` and the `gradle/` folder from the Forge 1.20.1 MDK into this folder (not its src/build.gradle).
3. `./gradlew build` -> `build/libs/modside-0.2.0.jar`.
4. Put the jar in the `mods/` folder of the client and/or the server (Forge 1.20.1, 47.x).

> Test with the built jar in a real instance; `runClient` does not load third-party mods well.
