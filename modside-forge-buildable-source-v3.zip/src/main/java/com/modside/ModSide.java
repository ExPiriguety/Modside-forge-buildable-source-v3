package com.modside;

import com.modside.client.ClientHooks;
import com.modside.commands.ServerCommands;
import com.modside.core.AnalysisCache;
import com.modside.core.I18n;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;

@Mod(ModSide.MODID)
public class ModSide {
    public static final String MODID = "modside";

    public ModSide() {
        // cria config/modside/modside.toml (idioma) na primeira execucao, no cliente e no servidor
        I18n.refresh(AnalysisCache.configDir());
        MinecraftForge.EVENT_BUS.addListener(ModSide::onCommands);
        // codigo de tela/tecla so existe no cliente: nunca e carregado no servidor dedicado
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::init);
    }

    private static void onCommands(RegisterCommandsEvent e) {
        ServerCommands.register(e.getDispatcher());
    }
}
