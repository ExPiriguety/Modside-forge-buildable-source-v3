package com.modside.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.modside.core.I18n;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.ConfigScreenHandler;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/** SOMENTE CLIENTE: tecla ] abre a tela do modside (configuravel em Controles). */
public final class ClientHooks {
    public static final KeyMapping OPEN = new KeyMapping("key.modside.open",
            InputConstants.KEY_RBRACKET, "key.categories.modside");

    private ClientHooks() { }

    public static void init() {
        // idioma automatico = idioma do jogo
        I18n.setAutoSupplier(() -> Minecraft.getInstance().options.languageCode);
        // botao "Config" do modside na tela Mods do Forge abre a tela de analise
        ModLoadingContext.get().registerExtensionPoint(ConfigScreenHandler.ConfigScreenFactory.class,
                () -> new ConfigScreenHandler.ConfigScreenFactory((mc, parent) -> new ModSideScreen(parent)));
        FMLJavaModLoadingContext.get().getModEventBus().addListener(ClientHooks::registerKeys);
        MinecraftForge.EVENT_BUS.addListener(ClientHooks::onTick);
    }

    private static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(OPEN);
    }

    private static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        while (OPEN.consumeClick()) {
            Minecraft.getInstance().setScreen(new ModSideScreen());
        }
    }
}
