package com.modside.client;

import com.modside.core.AnalysisCache;
import com.modside.core.I18n;
import com.modside.core.ModInfo;
import com.modside.core.Msg;
import com.modside.core.ReportWriter;
import com.modside.core.Result;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/** Tela: lista de mods (esq.) + detalhes/dependencias clicaveis (dir.) + legenda de cores. SOMENTE CLIENTE. */
public class ModSideScreen extends Screen {
    private static final int ROW = 12, LINE = 10;
    private static final int GRAY = 0xFF8B93A0, WHITE = 0xFFFFFFFF, RED = 0xFFFF6B6B, LINK = 0xFF7FB7FF;

    private record Line(FormattedCharSequence text, int color, int jump) { }

    private final Screen parent;
    private final CompletableFuture<Result> future = AnalysisCache.start(false);
    private Result res;
    private String error;
    private String filter = "ALL";
    private List<ModInfo> shown = new ArrayList<>();
    private ModInfo selected;
    private int listScroll, detailScroll;
    private final List<Line> detail = new ArrayList<>();
    private String status = "";
    private int listL, listR, listT, listB, detL, detR, statusX, statusW;

    public ModSideScreen() {
        this(null);
    }

    public ModSideScreen(Screen parent) {
        super(Component.literal("modside"));
        this.parent = parent;
        I18n.refresh(AnalysisCache.configDir());
    }

    @Override
    public void onClose() {
        if (minecraft != null) minecraft.setScreen(parent);
    }

    @Override
    protected void init() {
        listL = 10; listT = 56; listB = height - 36;
        listR = Math.max(150, width * 42 / 100);
        detL = listR + 10; detR = width - 10;
        String[][] filters = {{"ALL", "filter.all"}, {"CLIENT", "filter.client"}, {"SERVER", "filter.server"},
                {"BOTH", "filter.both"}, {"LIB", "filter.library"}, {"REMOVE", "filter.remove"}};
        int x = 10;
        for (String[] f : filters) {
            String key = f[0];
            String label = I18n.t(f[1]);
            int bw = font.width(label) + 14;
            addRenderableWidget(Button.builder(Component.literal(label), b -> { filter = key; applyFilter(); })
                    .bounds(x, 20, bw, 18).build());
            x += bw + 3;
        }
        String closeLabel = I18n.t("button.close");
        int closeW = font.width(closeLabel) + 20;
        addRenderableWidget(Button.builder(Component.literal(closeLabel), b -> onClose())
                .bounds(10, height - 26, closeW, 18).build());
        String repLabel = I18n.t("button.report");
        int repW = font.width(repLabel) + 20;
        addRenderableWidget(Button.builder(Component.literal(repLabel), b -> saveReport())
                .bounds(width - repW - 10, height - 26, repW, 18).build());
        statusX = 10 + closeW + 10;
        statusW = Math.max(40, width - repW - 20 - statusX);
        applyFilter();
        if (selected != null) buildDetail();
    }

    private void applyFilter() {
        if (res == null) { shown = new ArrayList<>(); return; }
        shown = res.mods.stream().filter(m -> switch (filter) {
            case "CLIENT", "SERVER", "BOTH" -> m.side.equals(filter);
            case "LIB" -> "LIBRARY".equals(m.kind);
            case "REMOVE" -> "REMOVE".equals(m.serverAction);
            default -> true;
        }).sorted(Comparator.comparing((ModInfo m) -> m.name == null ? "" : m.name.toLowerCase()))
                .collect(Collectors.toList());
        listScroll = 0;
    }

    @Override
    public void tick() {
        if (res == null && error == null && future.isDone()) {
            try {
                res = future.get();
                applyFilter();
            } catch (Exception e) {
                error = e.toString();
            }
        }
    }

    private static int sideColor(String s) {
        return switch (s) {
            case "CLIENT" -> 0xFF4AA3FF;
            case "SERVER" -> 0xFFF2A54A;
            case "BOTH" -> 0xFF6BD18A;
            default -> GRAY;
        };
    }

    private void add(String text, int color, int jump) {
        int w = detR - detL - 6;
        for (FormattedCharSequence s : font.split(Component.literal(text), w)) detail.add(new Line(s, color, jump));
    }

    private void buildDetail() {
        detail.clear();
        detailScroll = 0;
        if (selected == null) return;
        ModInfo m = selected;
        add(m.name, WHITE, -1);
        add(String.join(", ", m.ids) + "  v" + m.version + "  " + m.file, GRAY, -1);
        add(I18n.t("detail.type", I18n.t("kind." + m.kind)), 0xFFB48CFF, -1);
        add(I18n.t("detail.side", I18n.t("side." + m.side), I18n.t("conf." + m.confidence)), sideColor(m.side), -1);
        add(I18n.t("detail.action", I18n.t("action." + m.serverAction), I18n.t(m.clientNeeded ? "yes" : "no")), WHITE, -1);
        add(" ", WHITE, -1);
        add("-- " + I18n.t("panel.why") + " --", GRAY, -1);
        for (Msg k : m.kindReasons) add(I18n.t("detail.reasonType", k.render()), 0xFFCCCCCC, -1);
        for (Msg e : m.evidence) add(e.render(), "ev.warnClientButNeeded".equals(e.key) ? RED : 0xFFCCCCCC, -1);
        add(" ", WHITE, -1);
        add("-- " + I18n.t("panel.requires", m.requires.size()) + " --", GRAY, -1);
        for (ModInfo.Req r : m.requires) {
            String nm = r.jar != null ? res.mods.get(r.jar).name : r.id;
            String txt = "> " + nm + "  [" + I18n.t(r.mandatory ? "dep.required" : "dep.optional") + ", " + I18n.t("status." + r.status) + "]";
            int col = "missing".equals(r.status) ? RED : r.jar != null ? LINK : 0xFFCCCCCC;
            add(txt, col, r.jar != null ? r.jar : -1);
        }
        add(" ", WHITE, -1);
        add("-- " + I18n.t("panel.requiredBy", m.requiredBy.size()) + " --", GRAY, -1);
        for (ModInfo.ReqBy rb : m.requiredBy)
            add("< " + res.mods.get(rb.jar).name + "  [" + I18n.t(rb.mandatory ? "dep.required" : "dep.optional") + "]", LINK, rb.jar);
        if (!m.nested.isEmpty()) {
            add(" ", WHITE, -1);
            add("-- " + I18n.t("panel.nested") + " --", GRAY, -1);
            for (ModInfo.Nested n : m.nested) add(n.file + "  " + String.join(", ", n.ids), 0xFFCCCCCC, -1);
        }
    }

    private void select(ModInfo m) {
        selected = m;
        buildDetail();
    }

    private void jumpTo(int idx) {
        ModInfo t = res.mods.get(idx);
        if (!shown.contains(t)) { filter = "ALL"; applyFilter(); }
        select(t);
        listScroll = Math.max(0, shown.indexOf(t) - 3);
    }

    private void saveReport() {
        if (res == null) return;
        try {
            Path p = ReportWriter.write(res, AnalysisCache.configDir());
            status = I18n.t("screen.saved", p);
        } catch (Exception e) {
            status = I18n.t("screen.saveError", e);
        }
    }

    /** Legenda das tres cores: somente cliente / somente servidor / cliente + servidor. */
    private void drawLegend(GuiGraphics g) {
        int x = 10, y = 43;
        String title = I18n.t("legend.title");
        g.drawString(font, title, x, y, GRAY);
        x += font.width(title) + 8;
        for (String k : new String[]{"CLIENT", "SERVER", "BOTH"}) {
            g.fill(x, y, x + 8, y + 8, sideColor(k));
            x += 12;
            String label = I18n.t("legend." + k);
            g.drawString(font, label, x, y, 0xFFCCCCCC);
            x += font.width(label) + 14;
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.drawString(font, I18n.t("screen.title"), 10, 6, WHITE);
        drawLegend(g);
        if (res == null) {
            g.drawString(font, error != null ? I18n.t("screen.error", error) : I18n.t("screen.loading"), 10, listT, 0xFFAAAAAA);
            super.render(g, mx, my, pt);
            return;
        }
        long c = res.mods.stream().filter(m -> "CLIENT".equals(m.side)).count();
        long s = res.mods.stream().filter(m -> "SERVER".equals(m.side)).count();
        long b = res.mods.stream().filter(m -> "BOTH".equals(m.side)).count();
        String summary = I18n.t("screen.summary", res.mods.size(), c, s, b, shown.size());
        g.drawString(font, summary, Math.max(width / 2, width - 10 - font.width(summary)), 6, 0xFFAAAAAA);

        int rows = (listB - listT) / ROW;
        listScroll = Math.max(0, Math.min(listScroll, Math.max(0, shown.size() - rows)));
        g.fill(listL - 2, listT - 2, listR + 2, listB + 2, 0x66000000);
        String libTag = I18n.t("screen.libTag") + " ";
        for (int i = 0; i < rows && listScroll + i < shown.size(); i++) {
            ModInfo m = shown.get(listScroll + i);
            int y = listT + i * ROW;
            if (m == selected) g.fill(listL, y - 1, listR, y + ROW - 1, 0x55FFFFFF);
            String label = ("LIBRARY".equals(m.kind) ? libTag : "") + m.name;
            g.drawString(font, font.plainSubstrByWidth(label, listR - listL - 6), listL + 2, y + 1, sideColor(m.side));
        }

        int dRows = (listB - listT) / LINE;
        detailScroll = Math.max(0, Math.min(detailScroll, Math.max(0, detail.size() - dRows)));
        g.fill(detL - 2, listT - 2, detR + 2, listB + 2, 0x66000000);
        if (selected == null) g.drawString(font, I18n.t("screen.pick"), detL + 2, listT + 2, GRAY);
        for (int i = 0; i < dRows && detailScroll + i < detail.size(); i++) {
            Line ln = detail.get(detailScroll + i);
            g.drawString(font, ln.text(), detL + 2, listT + i * LINE, ln.color());
        }
        if (!status.isEmpty()) g.drawString(font, font.plainSubstrByWidth(status, statusW), statusX, height - 22, 0xFF6BD18A);
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (res == null || my < listT || my >= listB) return false;
        if (mx >= listL && mx <= listR) {
            int i = listScroll + (int) ((my - listT) / ROW);
            if (i >= 0 && i < shown.size()) select(shown.get(i));
            return true;
        }
        if (mx >= detL && mx <= detR) {
            int i = detailScroll + (int) ((my - listT) / LINE);
            if (i >= 0 && i < detail.size() && detail.get(i).jump() >= 0) jumpTo(detail.get(i).jump());
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        int step = delta > 0 ? -3 : 3;
        if (mx < listR + 4) listScroll += step; else detailScroll += step;
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
