package com.modside.commands;

import com.modside.core.*;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;

import java.nio.file.Path;

/** /modside report -> gera o relatorio em config/modside/ ;  /modside summary -> resumo no chat/console. */
public final class ServerCommands {
    private ServerCommands() { }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("modside")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("report").executes(ctx -> report(ctx.getSource())))
                .then(Commands.literal("summary").executes(ctx -> summary(ctx.getSource()))));
    }

    private static int report(CommandSourceStack src) {
        MinecraftServer server = src.getServer();
        I18n.refresh(AnalysisCache.configDir());
        src.sendSuccess(() -> Component.literal(I18n.t("cmd.analyzing")), false);
        AnalysisCache.start(true).thenAccept(res -> {
            try {
                Path html = ReportWriter.write(res, AnalysisCache.configDir());
                long rem = res.mods.stream().filter(m -> "REMOVE".equals(m.serverAction)).count();
                String msg = I18n.t("cmd.reportDone", I18n.t("client".equals(res.side) ? "where.client" : "where.server"),
                        res.mods.size(), rem, html);
                server.execute(() -> src.sendSuccess(() -> Component.literal(msg), true));
            } catch (Exception e) {
                String msg = I18n.t("cmd.error", e.toString());
                server.execute(() -> src.sendFailure(Component.literal(msg)));
            }
        }).exceptionally(t -> {
            String msg = I18n.t("cmd.failed", t.toString());
            server.execute(() -> src.sendFailure(Component.literal(msg)));
            return null;
        });
        return 1;
    }

    private static int summary(CommandSourceStack src) {
        MinecraftServer server = src.getServer();
        I18n.refresh(AnalysisCache.configDir());
        AnalysisCache.start(false).thenAccept(res -> {
            long c = res.mods.stream().filter(m -> "CLIENT".equals(m.side)).count();
            long s = res.mods.stream().filter(m -> "SERVER".equals(m.side)).count();
            long b = res.mods.stream().filter(m -> "BOTH".equals(m.side)).count();
            long l = res.mods.stream().filter(m -> "LIBRARY".equals(m.kind)).count();
            java.util.List<String> lines = new java.util.ArrayList<>();
            lines.add(I18n.t("cmd.summary", res.mods.size(), c, s, b, l));
            res.mods.stream().filter(m -> "REMOVE".equals(m.serverAction)).limit(15)
                    .forEach(m -> lines.add(I18n.t("cmd.removeLine", m.name, m.file)));
            server.execute(() -> lines.forEach(line -> src.sendSuccess(() -> Component.literal(line), false)));
        });
        return 1;
    }
}
