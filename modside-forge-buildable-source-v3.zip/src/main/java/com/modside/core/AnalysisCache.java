package com.modside.core;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.fml.loading.FMLPaths;

import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

/** Roda a analise em segundo plano (nao trava o jogo) e guarda o resultado. */
public final class AnalysisCache {
    private static CompletableFuture<Result> future;

    private AnalysisCache() { }

    public static Path configDir() {
        return FMLPaths.CONFIGDIR.get().resolve("modside");
    }

    public static synchronized CompletableFuture<Result> start(boolean force) {
        if (future == null || force) {
            future = CompletableFuture.supplyAsync(() -> {
                long t = System.currentTimeMillis();
                Result r = Analyzer.analyze(FMLPaths.MODSDIR.get(), Known.load(configDir()));
                r.modsDir = FMLPaths.MODSDIR.get().toString();
                r.side = FMLEnvironment.dist == Dist.CLIENT ? "client" : "server";
                r.millis = System.currentTimeMillis() - t;
                return r;
            });
        }
        return future;
    }
}
