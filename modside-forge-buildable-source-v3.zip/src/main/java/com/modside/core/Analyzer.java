package com.modside.core;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Classifica cada mod (lado + tipo) e monta o grafo de dependencias.
 * Codigos internos (sem idioma): side CLIENT/SERVER/BOTH/UNKNOWN; confidence HIGH/MEDIUM/LOW;
 * serverAction REMOVE/KEEP/REVIEW; status installed/missing/embedded/embedded_other/optional_absent.
 */
public final class Analyzer {
    private static final Pattern LIB_NAME = Pattern.compile("(lib|core|api|library)", Pattern.CASE_INSENSITIVE);

    private Analyzer() { }

    record SideResult(String side, String conf, List<Msg> ev) { }

    private static List<String> head(Collection<String> c, int n) {
        return c.stream().limit(n).collect(Collectors.toList());
    }

    private static String lastSeg(String p) {
        String s = p.endsWith("/") ? p.substring(0, p.length() - 1) : p;
        return s.substring(s.lastIndexOf('/') + 1);
    }

    static SideResult classify(ModInfo m, Known k) {
        for (String id : m.ids) {
            if (k.client_only.containsKey(id))
                return new SideResult("CLIENT", "MEDIUM", List.of(Msg.of("ev.known.client", id, k.client_only.get(id))));
            if (k.server_only.containsKey(id))
                return new SideResult("SERVER", "MEDIUM", List.of(Msg.of("ev.known.server", id, k.server_only.get(id))));
        }
        ModInfo.Signals s = m.signals;
        List<Msg> ev = new ArrayList<>();
        boolean client = !s.clientHits.isEmpty();
        boolean content = !s.contentHits.isEmpty() || s.assetContent;
        boolean server = !s.serverHits.isEmpty() || s.dataContent;
        if (client) ev.add(Msg.of("ev.clientClasses", s.clientClasses, s.classes, String.join(", ", head(s.clientHits, 3))));
        if (!s.contentHits.isEmpty())
            ev.add(Msg.of("ev.content", s.contentHits.stream().limit(4).map(Analyzer::lastSeg).collect(Collectors.joining(", "))));
        if (s.assetContent) ev.add(Msg.of("ev.assets"));
        if (!s.serverHits.isEmpty())
            ev.add(Msg.of("ev.serverLogic", s.serverHits.stream().limit(3).map(Analyzer::lastSeg).collect(Collectors.joining(", "))));
        if (s.dataContent) ev.add(Msg.of("ev.data"));
        String dt = m.displayTest;
        if (dt != null) ev.add(Msg.of("ev.displayTest", dt));
        if (Boolean.TRUE.equals(s.clientMixinOnly)) ev.add(Msg.of("ev.clientMixins"));

        if (client && !content && !server)
            return new SideResult("CLIENT", ("IGNORE_SERVER_VERSION".equals(dt) || Boolean.TRUE.equals(s.clientMixinOnly)) ? "HIGH" : "MEDIUM", ev);
        if (client && !content) {
            ev.add(Msg.of("ev.mixed"));
            return new SideResult("BOTH", "LOW", ev);
        }
        if (content) return new SideResult("BOTH", "MEDIUM", ev);
        if (server && !client) return new SideResult("SERVER", "MEDIUM", ev);
        ev.add(Msg.of("ev.noSignals"));
        return new SideResult("UNKNOWN", "LOW", ev);
    }

    public static Result analyze(Path dir, Known known) {
        Result r = new Result();
        List<ModInfo> mods = r.mods;
        List<Path> jars = new ArrayList<>();
        if (Files.isDirectory(dir)) {
            try (Stream<Path> st = Files.list(dir)) {
                jars = st.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".jar")).sorted().collect(Collectors.toList());
            } catch (IOException e) {
                r.skipped.add(new Result.Skipped(dir.toString(), Msg.of("skip.listError", e)));
            }
        }
        for (Path p : jars) {
            String fn = p.getFileName().toString();
            try {
                ModInfo m = JarScanner.read(p);
                if (m == null) r.skipped.add(new Result.Skipped(fn, Msg.of("skip.notForge")));
                else mods.add(m);
            } catch (Exception e) {
                r.skipped.add(new Result.Skipped(fn, Msg.of("skip.readError", e)));
            }
        }

        Map<String, Integer> provider = new HashMap<>(), nestedProv = new HashMap<>();
        for (int i = 0; i < mods.size(); i++) {
            ModInfo m = mods.get(i);
            m.idx = i;
            for (String id : m.ids) provider.put(id, i);
            for (ModInfo.Nested n : m.nested) for (String id : n.ids) nestedProv.putIfAbsent(id, i);
            SideResult sr = classify(m, known);
            m.sideDeclared = sr.side();
            m.confidence = sr.conf();
            m.evidence = new ArrayList<>(sr.ev());
        }
        for (ModInfo m : mods) {
            for (ModInfo.Dep d : m.deps) {
                Integer tgt = provider.get(d.id);
                String st;
                if (tgt != null && tgt != m.idx) {
                    st = "installed";
                } else {
                    tgt = null;
                    Integer np = nestedProv.get(d.id);
                    if (np != null) st = np == m.idx ? "embedded" : "embedded_other";
                    else st = d.mandatory ? "missing" : "optional_absent";
                }
                ModInfo.Req rq = new ModInfo.Req();
                rq.id = d.id; rq.mandatory = d.mandatory; rq.range = d.range; rq.status = st; rq.jar = tgt;
                m.requires.add(rq);
                if (tgt != null) {
                    ModInfo.ReqBy rb = new ModInfo.ReqBy();
                    rb.jar = m.idx; rb.mandatory = d.mandatory;
                    mods.get(tgt).requiredBy.add(rb);
                }
                if ("missing".equals(st)) m.missing.add(d.id);
            }
        }

        // tipo: biblioteca?
        for (ModInfo m : mods) {
            if (m.ids.stream().anyMatch(known.libraries::containsKey)) m.kindReasons.add(Msg.of("kr.knownLib"));
            boolean hasDependents = m.requiredBy.stream().anyMatch(x -> x.mandatory);
            ModInfo.Signals s = m.signals;
            if (hasDependents && s.contentHits.isEmpty() && !s.assetContent
                    && (LIB_NAME.matcher(m.ids.get(0)).find() || LIB_NAME.matcher(m.name == null ? "" : m.name).find()))
                m.kindReasons.add(Msg.of("kr.requiredNoContent"));
            m.kind = m.kindReasons.isEmpty() ? "MOD" : "LIBRARY";
        }

        // propagacao: dependencia obrigatoria de mod necessario tambem e necessaria
        int n = mods.size();
        boolean[] srv = new boolean[n], cli = new boolean[n];
        String[] whyS = new String[n], whyC = new String[n];
        for (int i = 0; i < n; i++) {
            ModInfo m = mods.get(i);
            String s = m.sideDeclared;
            if ("LIBRARY".equals(m.kind) && "UNKNOWN".equals(s)) continue;   // herda dos dependentes
            srv[i] = !"CLIENT".equals(s);
            cli[i] = !"SERVER".equals(s);
        }
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int i = 0; i < n; i++) {
                for (ModInfo.Req rq : mods.get(i).requires) {
                    if (rq.jar == null || !rq.mandatory) continue;
                    int j = rq.jar;
                    if (srv[i] && !srv[j]) { srv[j] = true; whyS[j] = mods.get(i).name; changed = true; }
                    if (cli[i] && !cli[j]) { cli[j] = true; whyC[j] = mods.get(i).name; changed = true; }
                }
            }
        }
        for (int i = 0; i < n; i++) {
            ModInfo m = mods.get(i);
            if ("LIBRARY".equals(m.kind) && "UNKNOWN".equals(m.sideDeclared) && m.requiredBy.isEmpty()) { srv[i] = true; cli[i] = true; }
            m.serverNeeded = srv[i];
            m.clientNeeded = cli[i];
            m.side = srv[i] && cli[i] ? "BOTH" : srv[i] ? "SERVER" : cli[i] ? "CLIENT" : "UNKNOWN";
            if (whyS[i] != null) m.evidence.add(Msg.of("ev.inherited.server", whyS[i]));
            if (whyC[i] != null) m.evidence.add(Msg.of("ev.inherited.client", whyC[i]));
            if ("CLIENT".equals(m.sideDeclared) && srv[i]) {
                m.evidence.add(Msg.of("ev.warnClientButNeeded"));
                m.hasWarning = true;
            }
            if (!srv[i]) m.serverAction = ("HIGH".equals(m.confidence) || "MEDIUM".equals(m.confidence)) ? "REMOVE" : "REVIEW";
            else m.serverAction = "UNKNOWN".equals(m.sideDeclared) ? "REVIEW" : "KEEP";
        }
        return r;
    }
}
