package com.modside.core;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;

/** Traducao propria (en / pt_br). Funciona tambem no servidor dedicado, que nao carrega lang de mods. */
public final class I18n {
    public enum Lang { EN, PT_BR }

    private static final Map<String, String> EN = load("en");
    private static final Map<String, String> PT = load("pt_br");
    private static volatile Supplier<String> autoSupplier = () -> "en_us";   // servidor: ingles
    private static volatile String setting = "auto";

    private I18n() { }

    /** O cliente informa aqui o idioma do jogo (ex.: "pt_br"). */
    public static void setAutoSupplier(Supplier<String> s) {
        autoSupplier = s;
    }

    /** Relê config/modside/modside.toml. */
    public static void refresh(Path configDir) {
        setting = Settings.language(configDir);
    }

    public static Lang lang() {
        String s = setting;
        if (s.equals("auto")) {
            String code;
            try {
                code = autoSupplier.get();
            } catch (Throwable t) {
                code = "en_us";
            }
            s = code == null ? "en" : code.toLowerCase(Locale.ROOT);
        }
        return s.startsWith("pt") ? Lang.PT_BR : Lang.EN;   // pt_br e pt_pt -> portugues; resto -> ingles
    }

    public static String t(String key, Object... args) {
        String s = lang() == Lang.PT_BR ? PT.get(key) : null;
        if (s == null) s = EN.get(key);
        if (s == null) return key;
        try {
            return args.length == 0 ? s : String.format(Locale.ROOT, s, args);
        } catch (Exception e) {
            return s;
        }
    }

    /** Todas as frases no idioma atual (ingles como base). Usado pelo relatorio HTML. */
    public static Map<String, String> dictionary() {
        Map<String, String> m = new LinkedHashMap<>(EN);
        if (lang() == Lang.PT_BR) m.putAll(PT);
        return m;
    }

    private static Map<String, String> load(String name) {
        try (InputStream in = I18n.class.getResourceAsStream("/modside_i18n/" + name + ".json")) {
            if (in == null) return new HashMap<>();
            Map<String, String> m = new Gson().fromJson(new InputStreamReader(in, StandardCharsets.UTF_8),
                    new TypeToken<Map<String, String>>() { }.getType());
            return m == null ? new HashMap<>() : m;
        } catch (Exception e) {
            return new HashMap<>();
        }
    }
}
