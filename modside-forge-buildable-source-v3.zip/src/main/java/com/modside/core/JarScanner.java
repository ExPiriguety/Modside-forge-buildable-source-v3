package com.modside.core;

import com.electronwill.nightconfig.core.Config;
import com.electronwill.nightconfig.toml.TomlParser;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/** Le um jar (somente leitura, nada e executado) e extrai metadados + sinais para classificacao. */
public final class JarScanner {
    private static final String[] CLIENT = {"net/minecraft/client/", "com/mojang/blaze3d/", "net/minecraftforge/client/"};
    private static final String[] CONTENT = {"net/minecraftforge/registries/DeferredRegister",
            "net/minecraftforge/registries/RegistryObject", "net/minecraftforge/event/RegisterEvent",
            "net/minecraftforge/network/simple/SimpleChannel", "net/minecraftforge/network/NetworkRegistry"};
    private static final String[] SERVER = {"net/minecraftforge/event/RegisterCommandsEvent",
            "net/minecraftforge/event/server/", "net/minecraftforge/server/", "net/minecraft/server/dedicated/"};
    private static final Pattern RE_ASSET = Pattern.compile("^assets/[^/]+/(blockstates|models/(block|item))/");
    private static final Pattern RE_DATA = Pattern.compile("^data/[^/]+/(recipes?|loot_tables?|advancements?|tags|worldgen|dimension)/");
    private static final Set<String> IGNORED = Set.of("minecraft", "forge", "neoforge", "java", "fml");

    private JarScanner() { }

    private static Config parseToml(byte[] bytes) {
        return new TomlParser().parse(new String(bytes, StandardCharsets.UTF_8));
    }

    /** @return null se o jar nao for um mod Forge (sem META-INF/mods.toml). */
    public static ModInfo read(Path path) throws IOException {
        try (ZipFile zf = new ZipFile(path.toFile())) {
            ZipEntry te = zf.getEntry("META-INF/mods.toml");
            if (te == null) return null;
            ModInfo m = new ModInfo();
            m.file = path.getFileName().toString();
            m.loader = "forge";

            Config doc;
            try (InputStream in = zf.getInputStream(te)) { doc = parseToml(in.readAllBytes()); }
            List<? extends Config> mods = doc.get("mods");
            if (mods == null || mods.isEmpty()) return null;
            for (Config mc : mods) {
                String id = mc.get("modId");
                if (id != null) m.ids.add(id);
            }
            if (m.ids.isEmpty()) return null;
            Config first = mods.get(0);
            String dn = first.get("displayName");
            m.name = dn != null ? dn : m.ids.get(0);
            Object ver = first.get("version");
            if (ver != null) m.version = ver.toString();
            String ds = first.get("description");
            if (ds != null) m.description = ds.trim().length() > 400 ? ds.trim().substring(0, 400) : ds.trim();
            String dtest = first.get("displayTest");
            if (dtest == null) dtest = doc.get("displayTest");
            m.displayTest = dtest;

            Config depTable = doc.get("dependencies");
            if (depTable != null) {
                for (String mid : m.ids) {
                    List<? extends Config> list = depTable.get(Collections.singletonList(mid));
                    if (list == null) continue;
                    for (Config d : list) {
                        String dm = d.get("modId");
                        if (dm == null || IGNORED.contains(dm.toLowerCase()) || m.ids.contains(dm)) continue;
                        Object mo = d.get("mandatory");
                        Object type = d.get("type");
                        ModInfo.Dep dep = new ModInfo.Dep();
                        dep.id = dm;
                        dep.owner = mid;
                        dep.mandatory = mo instanceof Boolean b ? b : !"optional".equals(String.valueOf(type));
                        Object vr = d.get("versionRange");
                        if (vr != null) dep.range = vr.toString();
                        Object sd = d.get("side");
                        if (sd != null) dep.side = sd.toString().toUpperCase();
                        m.deps.add(dep);
                    }
                }
            }
            List<? extends Config> mixins = doc.get("mixins");
            if (mixins != null) {
                for (Config mx : mixins) {
                    String cfg = mx.get("config");
                    if (cfg != null) m.mixinCfgs.add(cfg);
                }
            }

            ModInfo.Signals s = m.signals;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String n = e.getName();
                if (n.startsWith("META-INF/jarjar/") || n.startsWith("META-INF/jars/")) {
                    if (n.endsWith(".jar")) m.nested.add(readNested(zf, e));
                    continue;
                }
                if (n.endsWith(".class")) {
                    s.classes++;
                    String body;
                    try (InputStream in = zf.getInputStream(e)) {
                        body = new String(in.readAllBytes(), StandardCharsets.ISO_8859_1);
                    }
                    boolean hit = false;
                    for (String p : CLIENT) if (body.contains(p)) { s.clientHits.add(p); hit = true; }
                    if (hit) s.clientClasses++;
                    for (String p : CONTENT) if (body.contains(p)) s.contentHits.add(p);
                    for (String p : SERVER) if (body.contains(p)) s.serverHits.add(p);
                } else if (RE_ASSET.matcher(n).find()) {
                    s.assetContent = true;
                } else if (RE_DATA.matcher(n).find()) {
                    s.dataContent = true;
                }
            }
            for (String cfg : m.mixinCfgs) {
                ZipEntry ce = zf.getEntry(cfg);
                if (ce == null) continue;
                try (InputStream in = zf.getInputStream(ce)) {
                    JsonObject mj = JsonParser.parseString(new String(in.readAllBytes(), StandardCharsets.UTF_8)).getAsJsonObject();
                    boolean common = mj.has("mixins") && mj.getAsJsonArray("mixins").size() > 0;
                    boolean client = mj.has("client") && mj.getAsJsonArray("client").size() > 0;
                    boolean only = client && !common;
                    s.clientMixinOnly = s.clientMixinOnly == null ? only : (s.clientMixinOnly && only);
                } catch (Exception ignored) { }
            }
            return m;
        }
    }

    private static ModInfo.Nested readNested(ZipFile zf, ZipEntry e) {
        ModInfo.Nested nz = new ModInfo.Nested();
        String n = e.getName();
        nz.file = n.substring(n.lastIndexOf('/') + 1);
        try (ZipInputStream zis = new ZipInputStream(zf.getInputStream(e))) {
            ZipEntry ne;
            while ((ne = zis.getNextEntry()) != null) {
                if (ne.getName().equals("META-INF/mods.toml")) {
                    Config c = parseToml(zis.readAllBytes());
                    List<? extends Config> ms = c.get("mods");
                    if (ms != null) for (Config mc : ms) {
                        String id = mc.get("modId");
                        if (id != null) nz.ids.add(id);
                    }
                    break;
                }
            }
        } catch (Exception ignored) { }
        return nz;
    }
}
