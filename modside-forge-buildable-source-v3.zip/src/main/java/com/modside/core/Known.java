package com.modside.core;

import com.google.gson.Gson;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Banco editavel de mods conhecidos. Copiado para config/modside/known_mods.json na primeira vez. */
public class Known {
    public Map<String, String> client_only = new HashMap<>();
    public Map<String, String> server_only = new HashMap<>();
    public Map<String, String> libraries = new HashMap<>();

    public static Known load(Path configDir) {
        Gson gson = new Gson();
        try {
            Path f = configDir.resolve("known_mods.json");
            if (!Files.exists(f)) {
                Files.createDirectories(configDir);
                try (InputStream in = Known.class.getResourceAsStream("/known_mods.json")) {
                    Files.write(f, in.readAllBytes());
                }
            }
            Known k = gson.fromJson(new String(Files.readAllBytes(f), StandardCharsets.UTF_8), Known.class);
            if (k != null) return k;
        } catch (Exception ignored) { }
        return new Known();
    }
}
