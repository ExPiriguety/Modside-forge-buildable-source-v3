package com.modside.core;

import java.util.*;

/** Dados de um jar de mod. Campos publicos vao para o JSON do relatorio; os 'transient' sao internos. */
public class ModInfo {
    public int idx;
    public String file, loader, name, version = "?", description = "";
    public List<String> ids = new ArrayList<>();
    public List<Nested> nested = new ArrayList<>();

    public String side, sideDeclared, confidence, kind, serverAction;
    public boolean serverNeeded, clientNeeded, hasWarning;
    public List<Msg> evidence = new ArrayList<>();
    public List<Msg> kindReasons = new ArrayList<>();
    public List<String> missing = new ArrayList<>();
    public List<Req> requires = new ArrayList<>();
    public List<ReqBy> requiredBy = new ArrayList<>();

    public transient List<Dep> deps = new ArrayList<>();
    public transient List<String> mixinCfgs = new ArrayList<>();
    public transient String displayTest;
    public transient Signals signals = new Signals();

    public static class Nested { public String file; public List<String> ids = new ArrayList<>(); }
    public static class Dep { public String id, range = "", side = "BOTH", owner; public boolean mandatory; }
    public static class Req { public String id, range, status; public boolean mandatory; public Integer jar; }
    public static class ReqBy { public int jar; public boolean mandatory; }

    public static class Signals {
        public int classes, clientClasses;
        public Set<String> clientHits = new TreeSet<>(), contentHits = new TreeSet<>(), serverHits = new TreeSet<>();
        public boolean assetContent, dataContent;
        public Boolean clientMixinOnly;
    }
}
