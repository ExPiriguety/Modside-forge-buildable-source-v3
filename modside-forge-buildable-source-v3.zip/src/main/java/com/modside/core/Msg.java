package com.modside.core;

/** Mensagem traduzivel: chave + argumentos. O texto final so e gerado na hora de exibir/gravar (no idioma configurado). */
public final class Msg {
    public final String key;
    public final String[] args;

    public Msg(String key, String... args) {
        this.key = key;
        this.args = args;
    }

    public static Msg of(String key, Object... a) {
        String[] s = new String[a.length];
        for (int i = 0; i < a.length; i++) s[i] = String.valueOf(a[i]);
        return new Msg(key, s);
    }

    public String render() {
        return I18n.t(key, (Object[]) args);
    }
}
