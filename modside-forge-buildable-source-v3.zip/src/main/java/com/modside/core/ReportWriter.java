package com.modside.core;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializer;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Grava report-<lado>.html (interativo), report-<lado>.json e removable-from-server-<lado>.txt no idioma configurado. */
public final class ReportWriter {
    private ReportWriter() { }

    private static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /** @return caminho do HTML gerado */
    public static Path write(Result r, Path dir) throws IOException {
        Files.createDirectories(dir);
        I18n.refresh(dir);
        String side = r.side == null ? "unknown" : r.side;
        boolean client = side.equals("client");

        Gson gson = new GsonBuilder()
                .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
                .registerTypeAdapter(Msg.class, (JsonSerializer<Msg>) (src, t, ctx) -> new JsonPrimitive(src.render()))
                .create();
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("mods", r.mods);
        data.put("skipped", r.skipped);
        String json = gson.toJson(data);

        String tpl;
        try (InputStream in = ReportWriter.class.getResourceAsStream("/report_template.html")) {
            tpl = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
        String when = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        String origin = "<div class=\"sub\">" + esc(I18n.t("report.origin", r.modsDir == null ? "" : r.modsDir, when)) + "</div>";
        String html = tpl
                .replace("__LANG__", I18n.lang() == I18n.Lang.PT_BR ? "pt-BR" : "en")
                .replace("<h1>modside</h1>", "<h1>" + esc(I18n.t(client ? "report.title.client" : "report.title.server")) + "</h1>")
                .replace("<div class=\"sub\" id=\"sum\"></div>", origin + "<div class=\"sub\" id=\"sum\"></div>")
                .replace("__I18N__", gson.toJson(I18n.dictionary()).replace("</", "<\\/"))
                .replace("__DATA__", json.replace("</", "<\\/"));
        Path out = dir.resolve("report-" + side + ".html");
        Files.writeString(out, html, StandardCharsets.UTF_8);
        Files.writeString(dir.resolve("report-" + side + ".json"), json, StandardCharsets.UTF_8);

        StringBuilder sb = new StringBuilder(I18n.t(client ? "txt.header.client" : "txt.header.server"))
                .append('\n').append(I18n.t("txt.legend")).append("\n\n[REMOVE]\n");
        for (ModInfo m : r.mods)
            if ("REMOVE".equals(m.serverAction)) sb.append(m.file).append("   # ").append(m.name).append(" (").append(m.confidence).append(")\n");
        sb.append("\n[REVIEW]\n");
        for (ModInfo m : r.mods)
            if ("REVIEW".equals(m.serverAction)) sb.append(m.file).append("   # ").append(m.name).append(" (").append(m.confidence).append(")\n");
        Files.writeString(dir.resolve("removable-from-server-" + side + ".txt"), sb.toString(), StandardCharsets.UTF_8);
        return out;
    }
}
