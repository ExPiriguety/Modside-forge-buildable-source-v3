package com.modside.core;

import java.util.*;

public class Result {
    public String side;      // "client" ou "server"
    public long millis;
    public String modsDir;
    public List<ModInfo> mods = new ArrayList<>();
    public List<Skipped> skipped = new ArrayList<>();

    public static class Skipped {
        public String file;
        public Msg reason;
        public Skipped(String file, Msg reason) { this.file = file; this.reason = reason; }
    }
}
