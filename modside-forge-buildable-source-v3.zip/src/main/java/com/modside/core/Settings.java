package com.modside.core;

import com.electronwill.nightconfig.core.Config;
import com.electronwill.nightconfig.toml.TomlParser;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/** config/modside/modside.toml (criado na primeira execucao, em cliente e servidor). */
public final class Settings {
    private static final String DEFAULT = String.join("\n",
            "# modside configuration / configuracao do modside",
            "",
            "# Language of the screen, reports and command messages.",
            "# Idioma da tela, dos relatorios e das mensagens de comando.",
            "#   \"auto\"  -> client: follows the game language (Portuguese or English); server: English",
            "#   \"en\"    -> always English",
            "#   \"pt_br\" -> always Brazilian Portuguese",
            "language = \"auto\"",
            "");

    private Settings() { }

    public static String language(Path dir) {
        try {
            Path f = dir.resolve("modside.toml");
            if (!Files.exists(f)) {
                Files.createDirectories(dir);
                Files.writeString(f, DEFAULT, StandardCharsets.UTF_8);
                return "auto";
            }
            Config c = new TomlParser().parse(Files.readString(f, StandardCharsets.UTF_8));
            String v = c.get("language");
            return v == null ? "auto" : v.trim().toLowerCase(Locale.ROOT);
        } catch (Exception e) {
            return "auto";
        }
    }
}
